﻿// Copyright Natsu Neko, Inc. All Rights Reserved.

#pragma once


#include "IDetailCustomization.h"


class  UWallpaperCustomEditor : public IDetailCustomization
{
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailLyoutBuilder) override;
};
